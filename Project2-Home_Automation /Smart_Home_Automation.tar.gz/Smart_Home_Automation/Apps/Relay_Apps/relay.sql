use IOT_WEATHER_MONITORING;
select state from relay;
exit
