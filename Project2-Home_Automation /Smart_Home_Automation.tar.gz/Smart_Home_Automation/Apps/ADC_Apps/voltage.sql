use IOT_WEATHER_MONITORING;
update Monitoring set Value="125" where Parameter="Voltage";
exit
